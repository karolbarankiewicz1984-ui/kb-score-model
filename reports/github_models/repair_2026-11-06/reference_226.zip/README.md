# Referencyjna kohorta 226

Pierwszy etap diagnostyki: 11 lig historii, stary kod 40 przy dawnych 5 ligach / 46 przy tej samej historii; poprawiony resolver 76. To osobna kohorta i wcześniejszy cutoff 08:31:19 UTC, nie końcowe porównanie 488 spotkań. Zachowano pierwotne wartości i hashe; ścieżki audytów w starym JSON dokumentują miejsce ich pierwotnego utworzenia.
